import { useState } from "react";
import FormInput from "./FormInput"
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/16/solid'

export default function PasswordInput({ 
    label, name, id, placeholder, value, onChange
}) {

    const [show, setShow] = useState(false)

    const icon = show ? <EyeIcon /> : <EyeSlashIcon />
    const type = show ? 'text' : 'password'

    function handleIconClick() {
        setShow(!show)
    }

    return (
        <FormInput
            value={value}
            onChange={onChange}
            onIconClick={handleIconClick}
            icon={icon}
            label={label}
            type={type}
            name={name}
            id={id}
            placeholder={placeholder}
        />
    )
}