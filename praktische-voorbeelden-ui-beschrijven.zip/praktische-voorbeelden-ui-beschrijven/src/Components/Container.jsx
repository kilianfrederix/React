import './Container.css'

export default function Container({children}) {
    return (
        <div className='Container'>
            {children}
        </div>
    )
}