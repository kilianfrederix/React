import './Header.css'

export default function Header({title, subtitle}) {
    return (
        <header className="Header">
            <h2 className="Header-title">
                {title}
            </h2>
            {subtitle && (
                <p className="Header-subtitle">
                    {subtitle}
                </p>
            )}
        </header>
    )
}