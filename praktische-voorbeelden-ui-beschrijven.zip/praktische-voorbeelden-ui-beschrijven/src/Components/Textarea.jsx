import FormError from "./FormError"
import './Textarea.css'

export default function Textarea({ label, name, id, placeholder, error }) {
    return (
        <div className='Textarea'>
            <label className='Textarea-label'>
                <span className='Textarea-labelspan'>
                    {label}
                </span>

                <textarea 
                    className="Textarea-textarea"
                    name={name}
                    id={id}
                    placeholder={placeholder}
                ></textarea>

            </label>
            <FormError error={error} />
        </div>
    )
}