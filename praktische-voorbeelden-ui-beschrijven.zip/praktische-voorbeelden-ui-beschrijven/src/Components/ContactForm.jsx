import Button from "./Button/Button";
import FormInput from "./FormInput";
import FullNameInput from "./FullNameInput";
import Header from "./Header";
import Textarea from "./Textarea";
import './ContactForm.css'

export default function ContactForm() {
    return (
        <div className="ContactForm">
            <Header title="Contacteer ons" />
            <form action="" className="ContactForm-form">
                <FullNameInput />
                <FormInput
                    label="E-mailadres"
                    type="text"
                    name="username"
                    id="username"
                    placeholder="Geef je e-mailadres in"
                />
                <Textarea 
                    label="Bericht"
                    name="message"
                    id="message"
                    placeholder="Geef je bericht in"
                />
                <Button type="submit">Verzenden</Button>
            </form>
        </div>
    )
}