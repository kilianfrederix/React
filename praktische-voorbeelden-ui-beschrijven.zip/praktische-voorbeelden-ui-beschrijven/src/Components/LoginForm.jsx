import { useState } from "react"
import Button from "./Button/Button"
import FormInput from "./FormInput"
import Header from "./Header"
import './LoginForm.css'
import PasswordInput from "./PasswordInput"

export default function LoginForm({
    onLogin
}) {

    const [emailInput, setEmailInput] = useState('')
    const [passwordInput, setPasswordInput] = useState('')
    const [error, setError] = useState('')

    const username = 'admin'
    const password = 'test123'

    function handleSubmit(e) {
        e.preventDefault()

        if (emailInput === username && passwordInput === password) {
            onLogin()
        } else {
            setError('We kunnen je niet aanmelden met deze gegevens')
        }
    }

    return (
        <section className="LoginForm">
            <Header
                title="Aanmelden"
            />

            <form onSubmit={handleSubmit} className="LoginForm-form" action="">
                <FormInput
                    value={emailInput}
                    onChange={e => setEmailInput(e.target.value)}
                    error={error}
                    label="E-mailadres of username"
                    type="text"
                    name="username"
                    id="username"
                    placeholder="Geef je e-mailadres of username in"
                />
                <PasswordInput
                    value={passwordInput}
                    onChange={e => setPasswordInput(e.target.value)}
                    label="Wachtwoord"
                    name="password"
                    id="password"
                    placeholder="Geef je wachtwoord in"
                />
                <Button type="submit">Login</Button>
            </form>
        </section>
    )
}