import ContactForm from "./ContactForm";
import Container from "./Container";
import './Footer.css'

export default function Footer({ loggedIn }) {

    if (loggedIn) {
        return (
            <div className="Footer">
                <Container>
                    <ContactForm />
                </Container>
            </div>
        )
    }

    return (
        <div className="Footer">
            <Container>
                <p>Login to contact us</p>
            </Container>
        </div>
    )
}