import './Button.css'

export default function Button({ type="button", children }) {
    return (
        <button 
            className="Button"
            type={type}
        >
            <span>{children}</span>
            <span>&rarr;</span>
        </button>
    )
}