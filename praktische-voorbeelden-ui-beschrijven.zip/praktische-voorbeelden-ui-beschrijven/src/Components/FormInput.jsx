import FormError from './FormError'
import './FormInput.css'

export default function FormInput({
    label, type, name, id, placeholder, 
    error, icon, onIconClick, value, onChange
}) {
    return (
        <div className='FormInput'>
            <label className='FormInput-label'>
                <span className='FormInput-labelspan'>
                    {label}
                </span>

                <div className="FormInput-inputGroup">
                    <input
                        value={value}
                        onChange={onChange}
                        className='FormInput-input'
                        type={type}
                        name={name}
                        id={id}
                        placeholder={placeholder}
                    />
                    {icon && (
                        <div onClick={onIconClick} className="FormInput-icon">
                            {icon}
                        </div>
                    )}
                </div>

            </label>
            <FormError error={error} />
        </div>
    )
}