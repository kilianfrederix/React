import { useState } from 'react'
import Container from './Container'
import LoginForm from './LoginForm'
import RegisterForm from './RegisterForm'

export default function Tabs({ 
    loggedIn, onLogin, onLogout 
}) {

    const [currentTab, setCurrentTab] = useState('aanmelden')
    
    const form = currentTab === 'aanmelden' ? 
        <LoginForm onLogin={onLogin} /> : <RegisterForm />

    if (loggedIn) {
        return (
            <Container>
                <p>
                    Welcome to this website!
                </p>
                <p>
                    <button 
                        type="button" 
                        onClick={onLogout}
                    >Logout</button>
                </p>
            </Container>
        )
    }

    return (
        <Container>
            <div style={{ display: 'flex', gap: 15 }}>
                <button type='button' onClick={() => setCurrentTab('aanmelden')}>Aanmelden</button>
                <button type='button' onClick={() => setCurrentTab('registreren')}>Registreren</button>
            </div>
            <div>
                {form}
            </div>
        </Container>
    )
}