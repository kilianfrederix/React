import FullNameInput from './FullNameInput'
import FormInput from './FormInput'
import Button from './Button/Button'
import './RegisterForm.css'
import Header from './Header'
import PasswordInput from './PasswordInput'

export default function RegisterForm() {
    return (
        <section className="RegisterForm">
            <Header 
                title="Registeren"
                subtitle="Registreer een nieuwe account"
            />

            <form action="" className='RegisterForm-form'>
                <FullNameInput />
                <FormInput
                    label="E-mailadres"
                    type="text"
                    name="email"
                    id="email"
                    placeholder="Geef je e-mailadres in"
                />
                <FormInput
                    label="Username"
                    type="text"
                    name="username"
                    id="username"
                    placeholder="Geef je username in"
                />
                <PasswordInput
                    label="Wachtwoord"
                    name="password"
                    id="password"
                    placeholder="Geef je wachtwoord in"
                />
                <PasswordInput
                    label="Wachtwoord confirmatie"
                    name="password_confirmation"
                    id="password_confirmation"
                    placeholder="Geef je wachtwoord normaals in"
                />

                <Button>Register</Button>
            </form>
        </section>
    )
}