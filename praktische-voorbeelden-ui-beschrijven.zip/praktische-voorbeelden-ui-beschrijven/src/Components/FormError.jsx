import './FormError.css'

export default function FormError({error}) {
    if (!error) return null 

    return (
        <div className="FormError">
            {error}
        </div>
    )
}