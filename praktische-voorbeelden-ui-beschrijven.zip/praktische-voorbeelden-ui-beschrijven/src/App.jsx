import './App.css';
import Footer from './Components/Footer';
import Tabs from './Components/Tabs';
import { useState } from 'react';

function App() {
  const [loggedIn, setLoggedIn] 
    = useState(false)

  function handleLogin() {
    setLoggedIn(true)
  }

  function handleLogout() {
    setLoggedIn(false)
  }

  return (
    <div className="App">
      <Tabs
        loggedIn={loggedIn}
        onLogin={handleLogin}
        onLogout={handleLogout}
      />
      <Footer 
        loggedIn={loggedIn} 
      />
    </div>
  );
}

export default App;
